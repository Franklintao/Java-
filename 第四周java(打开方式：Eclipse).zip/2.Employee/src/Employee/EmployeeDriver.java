package Employee;

public class EmployeeDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp1=new Employee("123456","Tom",9000000f,1f);
		emp1.Growth();
		emp1.diaplayEmployee();
	}

}
