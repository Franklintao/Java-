package Address;

public class Address {
	public String Country;
	public String Provice;
	public String City;
	public String Street;
	public String Postcode;
	
	public Address(String Country,String Provice,String City,String Street,String Postcode) {
		this.Country=Country;
		this.Provice=Provice;
		this.City=City;
		this.Street=Street;
		this.Postcode=Postcode;
	}
	
	public void displayAddress() {
		System.out.println(this.Country+" "+this.Provice+" "+this.City+" "+this.Street+" "+this.Postcode);
	}

}
