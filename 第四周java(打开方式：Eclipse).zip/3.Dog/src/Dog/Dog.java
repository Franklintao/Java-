package Dog;

public class Dog {
	private String Name;
	private String Color;
	private int Age;
	
	public Dog(String Name,String Color,int Age) {
		this.Color=Color;
		this.Name=Name;
		this.Age=Age;
	}
	
	public void displayDog() {
		System.out.println("����:"+Name+"\n��ɫ:"+Color+"\n����:"+Age);
	}
}
