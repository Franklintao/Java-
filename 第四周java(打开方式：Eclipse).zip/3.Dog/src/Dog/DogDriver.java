package Dog;

public class DogDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog dog1=new Dog("��Ϊ","��ɫ",20);
		dog1.displayDog();
	}

}
