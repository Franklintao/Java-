package User;
public class UserDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User user1=new User("Tom","123456");
		User user2=new User("Lisa");
		User user3=new User();
		user1.tell();
		user2.tell();
		user3.tell();
	}

}
