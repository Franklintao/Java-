package User;
public class User {
	private String UserName;
	private String Command;
	public int UserNum=1;
	
	public User(String UserName,String Command) {
		this.UserName=UserName;
		this.setcommand(Command);
	}
	
	
	public User(String UserName) {
		this.UserName=UserName;
	}
	
	
	public User() {
		this.UserNum=0;
	}
	
	
	public String getcommand() {
		return this.Command;
	}
	
	
	public void setcommand(String a) {
		this.Command=a;
	}
	
	
	public void tell() {
		System.out.println("�û���:"+this.UserName+"\n����:"+this.getcommand()+"\n�û�����Ϊ:"+this.UserNum);
	}
}
